# Databricks notebook source
# MAGIC %md
# MAGIC ### **Dynamic Capabilities**

# COMMAND ----------

dbutils.widgets.text("file_name","")

# COMMAND ----------

p_file_name=dbutils.widgets.get("file_name")

# COMMAND ----------

p_file_name

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df=spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format","parquet")\
        .option("cloudFiles.schemaLocation",f"abfss://bronze@databricksetese2.dfs.core.windows.net/checkpoint_{p_file_name}")\
            .load(f"abfss://source@databricksetese2.dfs.core.windows.net/{p_file_name}")

# COMMAND ----------

#display(df.limit(5), checkpointLocation = "abfss://bronze@databricksetese2.dfs.core.windows.net/checkpoint_orders")

# COMMAND ----------

# DBTITLE 1,Cell 5
df.writeStream.format("parquet")\
    .outputMode("append")\
        .option("checkpointLocation",f"abfss://bronze@databricksetese2.dfs.core.windows.net/checkpoint_{p_file_name}_sink")\
        .option("path",f"abfss://bronze@databricksetese2.dfs.core.windows.net/{p_file_name}")\
        .trigger(once=True)\
        .start()

# COMMAND ----------

df1=spark.read.parquet(f"abfss://bronze@databricksetese2.dfs.core.windows.net/{p_file_name}")
display(df1)

# COMMAND ----------

