# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df=spark.read.format("parquet")\
    .load("abfss://bronze@databricksetese2.dfs.core.windows.net/customers")

# COMMAND ----------

df.display()

# COMMAND ----------

df=df.drop("_rescued_data")

# COMMAND ----------

df.display()

# COMMAND ----------

df=df.withColumn("domain",split("email","@")[1])
df.display()

# COMMAND ----------

df.groupBy("domain").agg(count("customer_id").alias("total_customers")).sort(desc("total_customers")).display()


# COMMAND ----------

df_gmail=df.filter(col("domain")=="gmail.com")
df_gmail.display()

df_yahoo=df.filter(col("domain")=="yahoo.com")
df_yahoo.display()

df_hotmail=df.filter(col("domain")=="hotmail.com")
df_hotmail.display()


# COMMAND ----------

df=df.withColumn("Full_name",concat(col("first_name"),lit(" "),col("last_name")))
df=df.drop('first_name','last_name')
df.display()

# COMMAND ----------

df.write.mode("overwrite").format('delta').save('abfss://silver@databricksetese2.dfs.core.windows.net/customers')

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists databricks_cata.silver.customer_silver
# MAGIC using delta
# MAGIC location 'abfss://silver@databricksetese2.dfs.core.windows.net/customers'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from databricks_cata.silver.customer_silver