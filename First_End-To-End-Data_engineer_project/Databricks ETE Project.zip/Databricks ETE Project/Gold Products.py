# Databricks notebook source
# DBTITLE 1,Pipeline Overview
# MAGIC %md
# MAGIC ### Gold Products Pipeline
# MAGIC
# MAGIC This notebook defines the Gold layer SCD Type 2 product dimension in Lakeflow Spark Declarative Pipelines.
# MAGIC
# MAGIC * Source table: `databricks_cata.silver.product_silver`
# MAGIC * Target dataset: `databricks_cata.gold.dimproducts`
# MAGIC * Execution mode: serverless pipeline refresh
# MAGIC * Pattern used: snapshot-based Auto CDC with SCD Type 2 history

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark import pipelines as dp

# COMMAND ----------

# DBTITLE 1,Design Notes
# MAGIC %md
# MAGIC ### Dataset Design
# MAGIC
# MAGIC This notebook uses snapshot-based Auto CDC to build an SCD Type 2 Gold dimension.
# MAGIC
# MAGIC * `dimproducts` is created as the target table in the pipeline target schema `databricks_cata.gold`.
# MAGIC * The source snapshot is `databricks_cata.silver.product_silver`.
# MAGIC * No column projection is hardcoded, so new source columns can flow through automatically.
# MAGIC * The pipeline manages historical versions with `__START_AT` and `__END_AT`.

# COMMAND ----------

# DBTITLE 1,Gold Product Dimension
dp.create_streaming_table(
    name="dimproducts",
    comment="Gold SCD Type 2 product dimension built from databricks_cata.silver.product_silver snapshots."
)

dp.create_auto_cdc_from_snapshot_flow(
    target="dimproducts",
    source="databricks_cata.silver.product_silver",
    keys=["product_id"],
    stored_as_scd_type=2,
)

# COMMAND ----------

# DBTITLE 1,Publishing Notes
# MAGIC %md
# MAGIC ### Publishing Notes
# MAGIC
# MAGIC After a successful refresh, this notebook creates and loads `databricks_cata.gold.dimproducts`.
# MAGIC
# MAGIC The table is maintained as SCD Type 2 history, so current records have `__END_AT IS NULL` and historical versions are preserved automatically.