# Databricks notebook source
df=spark.read.table("databricks_cata.bronze.regions")

# COMMAND ----------

df.display()

# COMMAND ----------

df=df.drop("_rescued_data")
df.display()

# COMMAND ----------

df.write.mode('overwrite').format('delta').save('abfss://silver@databricksetese2.dfs.core.windows.net/regions')

# COMMAND ----------

df=spark.read.format('delta')\
    .load("abfss://silver@databricksetese2.dfs.core.windows.net/products")
df.display()


# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists databricks_cata.silver.regions_silver
# MAGIC using delta
# MAGIC location 'abfss://silver@databricksetese2.dfs.core.windows.net/regions'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from databricks_cata.silver.regions_silver