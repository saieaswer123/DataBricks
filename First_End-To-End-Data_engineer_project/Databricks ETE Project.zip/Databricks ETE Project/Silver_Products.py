# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df=spark.read.format("parquet")\
    .load('abfss://bronze@databricksetese2.dfs.core.windows.net/products')

# COMMAND ----------

df.display()

# COMMAND ----------

df=df.drop("_rescued_data")

# COMMAND ----------

df.display()

# COMMAND ----------

df.createOrReplaceTempView("products")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Functions**

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace function databricks_cata.bronze.discount_func(p_price double) returns double 
# MAGIC language sql
# MAGIC return p_price*0.90

# COMMAND ----------

# MAGIC %sql
# MAGIC select product_id,price,databricks_cata.bronze.discount_func(price) as discounted_price from products

# COMMAND ----------

# DBTITLE 1,Cell 11
df=df.withColumn("discount_price",expr("databricks_cata.bronze.discount_func(price)"))
df.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE FUNCTION if not EXISTS databricks_cata.bronze.upper_func(p_brand STRING) RETURNS STRING
# MAGIC LANGUAGE PYTHON
# MAGIC AS
# MAGIC $$
# MAGIC     return p_brand.upper()
# MAGIC $$

# COMMAND ----------

# MAGIC %sql
# MAGIC select product_id,brand,databricks_cata.bronze.upper_func(brand) as brand_upper from products
# MAGIC

# COMMAND ----------

df.write.format('delta').mode('overwrite').save('abfss://silver@databricksetese2.dfs.core.windows.net/products')

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists databricks_cata.silver.product_silver
# MAGIC using delta
# MAGIC location 'abfss://silver@databricksetese2.dfs.core.windows.net/products'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from databricks_cata.silver.product_silver