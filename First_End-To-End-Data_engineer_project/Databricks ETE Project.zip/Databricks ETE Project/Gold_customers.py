# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *


# COMMAND ----------

# DBTITLE 1,Cell 2
dbutils.widgets.text("init_load_flag", '1')  # or "1", whichever is correct
init_load_flag = int(dbutils.widgets.get("init_load_flag"))

# COMMAND ----------

init_load_flag

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Read Data**

# COMMAND ----------

df=spark.sql("""
             select * from databricks_cata.silver.customer_silver""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Removig Duplicate**

# COMMAND ----------

df=df.dropDuplicates(subset=['customer_id'])

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Dividing New VS Old records**

# COMMAND ----------

if init_load_flag==0:

    df_old=spark.sql('''
                     select DimCustomerKey,customer_id,create_date,update_date from databricks_cata.gold.DimCustomer''')
    
else:

    df_old=spark.sql(''' 
                    select 0 DimCustomerKey,0 customer_id,0 create_date,0 update_date from databricks_cata.silver.customer_silver where 1=0 ''')

# COMMAND ----------

df_old.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Renaming columns of df_old**

# COMMAND ----------

df_old=df_old.withColumnRenamed("DimCustomerKey","old_DimCustomerKey")\
    .withColumnRenamed("customer_id","old_customer_id")\
    .withColumnRenamed("create_date","old_create_date")\
    .withColumnRenamed("update_date","old_update_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Applying the join with old recordes**

# COMMAND ----------

df_join=df.join(df_old,df.customer_id==df_old.old_customer_id,'left')

# COMMAND ----------

df_join.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Seperating new vs old records**

# COMMAND ----------

df_new=df_join.filter(df_join['old_DimCustomerKey'].isNull()) 

# COMMAND ----------

df_old=df_join.filter(df_join['old_DimCustomerKey'].isNotNull()) 

# COMMAND ----------

# MAGIC %md
# MAGIC **Preparing df_old**

# COMMAND ----------

# Dropping all the columns which are not requried
df_old=df_old.drop('old_customer_id','old_update_date')

#renaming "old_DimCustomerKey" column to "DimCustomerKey"
df_old=df_old.withColumnRenamed("old_DimCustomerKey","DimCustomerKey")

# Renaming create date column "old_create_date" to "create_date"
df_old=df_old.withColumnRenamed("old_create_date","create_date")
df_old=df_old.withColumn("create_date",to_timestamp(col("create_date")))
#Recreationg "Update_date"
df_old=df_old.withColumn("update_date",current_timestamp())


# COMMAND ----------

df_old.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Preparing df_new**

# COMMAND ----------

# Dropping all the columns which are not requried
df_new=df_new.drop('old_DimCustomerKey','old_customer_id','old_update_date','old_create_date')


#Recreationg "Update_date" and "current_date" column with current timestamp
df_new=df_new.withColumn("update_date",current_timestamp())
df_new=df_new.withColumn("create_date",current_timestamp())



# COMMAND ----------

df_new.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Surrogate key - from 1**

# COMMAND ----------

df_new=df_new.withColumn("DimCustomerKey",monotonically_increasing_id()+lit(1))


# COMMAND ----------

df_new.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Adding max Surrogate Key**

# COMMAND ----------

if init_load_flag==1:
    max_surrogate_key=0
else:
    df_maxsur=spark.sql('select max(DimCustomerKey) as max_surrogate_key from databricks_cata.gold.DimCustomers')
    # Convertiong df_maxsur to max_surrogate_key variable
    max_surrogate_key=df_maxsur.collect()[0]['max_surrogate_key']

# COMMAND ----------

df_new=df_new.withColumn("DimCustomerKey",lit(max_surrogate_key)+col("DimCustomerKey"))

# COMMAND ----------

# MAGIC %md
# MAGIC **Unio of df_old and df_new**

# COMMAND ----------

df_final=df_new.unionByName(df_old)

# COMMAND ----------

df_final.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **SCD Type 1**

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if spark.catalog.tableExists("databricks_cata.gold.DimCustomers"):
    dlt_obj=DeltaTable.forPath(spark,"abfss://gold@databricksetese2.dfs.core.windows.net/DimCustomers")
   
    dlt_obj.alias("trg").merge(df_final.alias("src"),"trg.DimCustomerKey=src.DimCustomerKey").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
else:
    df_final.write.mode("overwrite").option("path","abfss://gold@databricksetese2.dfs.core.windows.net/DimCustomers").saveAsTable("databricks_cata.gold.DimCustomers")