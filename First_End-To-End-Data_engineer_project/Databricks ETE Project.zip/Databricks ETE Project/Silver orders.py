# Databricks notebook source
# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df=spark.read.format('parquet')\
    .load("abfss://bronze@databricksetese2.dfs.core.windows.net/orders")

# COMMAND ----------

display(df)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.withColumnRenamed('_rescued_data','rescued_data').display()

# COMMAND ----------

df=df.drop("_rescued_data")

# COMMAND ----------

df.display()

# COMMAND ----------

# DBTITLE 1,Cell 8
from pyspark.sql.functions import *
df=df.withColumn("order_date",to_timestamp(col('order_date')))
df.display()

# COMMAND ----------

df=df.withColumn("year",year((col('order_date'))))
df.display()

# COMMAND ----------

from pyspark.sql.window import Window
df1=df.withColumn("flag",dense_rank().over(Window.partitionBy("year").orderBy(desc("total_amount"))))
df1.display()

# COMMAND ----------

from pyspark.sql.window import Window
df1=df1.withColumn("rank_flag",rank().over(Window.partitionBy("year").orderBy(desc("total_amount"))))
df1.display()

# COMMAND ----------

from pyspark.sql.window import Window
df1=df1.withColumn("row_flag",row_number().over(Window.partitionBy("year").orderBy(desc("total_amount"))))
df1.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Classes-oops**

# COMMAND ----------

class window:

    def dense_rank(self,df):
        df_dense_rank=df.withColumn("dense_rank",dense_rank().over(Window.partitionBy("year").orderBy(desc("total_amount"))))
        return df_dense_rank

    def rank(self,df):
        df_rank=df.withColumn("rank",rank().over(Window.partitionBy("year").orderBy(desc("total_amount"))))
        return df_rank

    def row_number(self,df):
        df_row_number=df.withColumn("row_number",row_number().over(Window.partitionBy("year").orderBy(desc("total_amount"))))
        return df_row_number


# COMMAND ----------

df_new=df

# COMMAND ----------

df_new.display()

# COMMAND ----------

obj=window()

# COMMAND ----------

df_result=obj.dense_rank(df_new)
df_result.display()

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Writing**

# COMMAND ----------

df.write.format("delta").mode("overwrite").save("abfss://silver@databricksetese2.dfs.core.windows.net/orders")

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists databricks_cata.silver.orders_silver
# MAGIC using delta
# MAGIC location 'abfss://silver@databricksetese2.dfs.core.windows.net/orders'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from databricks_cata.silver.orders_silver